var character = {
	name		: "mario",
	images 		: {
		main    : "mario"
	},
	attributes	: {
		speed 	: 2,
		startX 	: 50,
		startY 	: 50
	}
}
