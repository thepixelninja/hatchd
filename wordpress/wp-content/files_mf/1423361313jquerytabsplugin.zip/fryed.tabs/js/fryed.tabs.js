/*-------------------------------//
 * 
 * FRYED.TABS.JS
 * JQUERY TABS PLUGIN
 * WRITTEN BY ED FRYER
 * WWW.FRYED.CO.UK
 * 
 -------------------------------*/

jQuery.fn.fryedTabs = function(options) {
	
	var defaults = {
		openOn	:	1	//the default tab to open on. Note: if anchor is set in url with tab id then this value will be over written
	};
 
  	var options = $.extend(defaults,options);
	
	return this.each(function(){
		
		//setup tabs
		var element = $(this);
		element.addClass("tabNav").wrap("<div class='fryedTabHolder'></div>").after("<div class='tabContent'></div>");
		var tabContent = element.parent(".fryedTabHolder").find(".tabContent");
		
		//hide any tab content on page
		element.find("li").each(function(i){
			i++;
			$(this).attr("id","tab"+i);
			var href = $(this).find("a").attr("href");
			$(href).hide("");
		});
		
		//open tab set in options unless anchor is set
		var anchor = window.location.hash;
		var isTab = anchor.lastIndexOf("tab");
		if(isTab != -1)
			var open = element.find(anchor);
		if($(open).attr("id") === undefined)
			var open = element.find("li:nth-child("+options.openOn+")");
		openTab(open);

		//handle click on tabs
		element.find("a").click(function(e){
			e.preventDefault();
			var open = $(this).parent("li");
			openTab(open);
		});
		
		//function to open tabs
		function openTab(open){
			element.find("li").removeClass("active");
			open.addClass("active");
			var href = open.find("a").attr("href");
			var hasAnchor = href.lastIndexOf("#");
			var id = "";
			if(hasAnchor != -1){
				hrefArray = href.split("#");
				href = hrefArray[0];
				id 	 = "#"+hrefArray[1];
				if(href == ""){
					var target = $(id);
					if(target.length > 0){
						var content = target.html();
						tabContent.html(content);
					}
				}else{
					href = href+" "+id;
					tabContent.load(href);
				}
			}else{
				tabContent.load(href);
			}
		}
		
	});
	
}	