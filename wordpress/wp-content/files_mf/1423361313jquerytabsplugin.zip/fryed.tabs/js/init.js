//perform when page is ready
$(document).ready(function(){
	
	//init tab function
	$("#tabs").fryedTabs();
	
});