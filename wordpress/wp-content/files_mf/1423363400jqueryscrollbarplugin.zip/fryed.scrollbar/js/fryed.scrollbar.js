/*-------------------------------//
 * 
 * FRYED.SCROLLBAR.JS
 * JQUERY SCROLLBAR PLUGIN JS
 * WRITTEN BY ED FRYER
 * WWW.FRYED.CO.UK
 * 
 -------------------------------*/

/*----------FRYED SCROLL----------*/

$.fn.fryedScroll = function(options){
	
	var defaults = {
		bgColor 		: "#ccc",
		draggerColor 	: "#000"
	}
	
	var options = $.extend(defaults,options);
	var data	= new Object;
	
	return this.each(function(){
		
		//----------SETUP----------//
		
		//define el
		var el = $(this);
		
		//create unique id
		if(!window.fryedScrollId){
			window.fryedScrollId = 1;
		}else{
			window.fryedScrollId++;
		}
		var id 	= "fryedScroll"+window.fryedScrollId;
		
		//get els padding
		padding = {
			top 	: el.css("padding-top"),
			left	: el.css("padding-left"),
			bottom 	: el.css("padding-bottom"),
			right 	: el.css("padding-right")
		}
		
		//style el
		el.css({
			"overflow" 	: "hidden",
			"position"	: "relative",
			"padding"	: "0px"
		});
		
		//set vars
		var height 		= el.height();
		var width		= el.width();
		var content 	= el.html();
		data.mousedown  = false;
		data.dragging	= false;
		
		//add id
		el.attr("id",id);
		
		//append scroll div and remove old html
		el.html("").append("<div class='fryedScrollDiv'>"+content+"</div>");
		
		//define scrollDiv
		var scrollDiv  = el.find(".fryedScrollDiv");
		var _scrollDiv = document.getElementById(id);
		
		//style scrollDiv
		var padCorrection = parseFloat(padding.left)+parseFloat(padding.right);
		scrollDiv.css({
			"position"  		: "absolute",
			"width"				: width-20-padCorrection,
			"padding-top"		: padding.top,
			"padding-left"		: padding.left,
			"padding-bottom"	: padding.bottom,
			"padding-right"		: padding.right
		});
		
		//get scroll height
		var scrollHeight = scrollDiv.outerHeight();
		
		//add scrollbar
		el.append("<div class='fryedScrollBar'><div class='fryedScrollDragger' data-dragId='"+window.fryedScrollId+"'></div></div>");
		
		//define scrollbar and dragger
		var scrollbar 	= el.find(".fryedScrollBar");
		var dragger 	= el.find(".fryedScrollDragger");
		
		//stop selection of scrollbar
		scrollbar
			.attr("unselectable","on")
			.css({
				"-moz-user-select"		: 	"none",
				"-webkit-user-select"	: 	"none",
				"user-select"			: 	"none"
			})
			.each(function(){
				$(this).unbind("onselectstart");
			})
		;
		
		//style scrollbar
		scrollbar.css({
			"width" 		: "15px",
			"height" 		: height,
			"background"	: options.bgColor,
			"position" 		: "absolute",
			"top"			: "0px",
			"right"			: "0px"
		});
		
		//work out dragger height
		var fract 			= height/scrollHeight;
		var draggerHeight 	= Math.floor(height*fract);
		
		//style dragger
		dragger.css({
			"width" 		: "15px",
			"height" 		: draggerHeight,
			"background"	: options.draggerColor,
			"position"		: "absolute",
			"cursor"		: "pointer"
		});
		
		//----------EVENTS----------//
		
		//-----log mouse down-----//
		$("body").mousedown(function(){
			data.mousedown = true;
		});
		dragger.mousedown(function(){
			data.dragging 	= true;
			data.dragId		= $(this).attr("data-dragId");
		});
		
		//-----log mouse up-----//
		$("body").mouseup(function(){
			data.mousedown = false;
			data.dragging = false;
			stopScroll();
		});
		
		//-----mouse move-----//
		$("body").mousemove(function(e){
			if(data.mousedown && data.dragging){
				e.preventDefault();
				scroll(e);
			}
		});
		
		//-----log when over scrollable area-----//
		$(".fryedScroll").mouseover(function(){
			data.activeScroll = this;
		});
		$(".fryedScroll").mouseout(function(){
			data.activeScroll = null;
		});
		
		//-----detect mouse wheel-----//
		if($.browser.mozilla){
			_scrollDiv.addEventListener("DOMMouseScroll",function(e){
				e.preventDefault();
				var raw = e.detail ? e.detail : e.wheelDelta;
				scrollWheel(this,raw);
			}); 
		}else{
			window.onmousewheel = document.onmousewheel = function(e){
				if(data.activeScroll){
					e = window.event;
					var raw = e.detail ? e.detail : e.wheelDelta;
					var raw = raw*-1;
					scrollWheel(data.activeScroll,raw);
				}
			};
		}
		
		//----------FUNCTONS----------//
		
		//-----scroll function-----//
		function scroll(e){
			
			//get scrollable div
			var fryedScroll 	= $("#fryedScroll"+data.dragId);
			
			//stop text from selecting
			fryedScroll.find(".fryedScrollDiv")
				.attr("unselectable","on")
				.css({
					"-moz-user-select"		: 	"none",
					"-webkit-user-select"	: 	"none",
					"user-select"			: 	"none"
				})
				.each(function(){
					$(this).unbind("onselectstart");
				})
			;
			
			//get dragger pos
			var pos 		= fryedScroll.find(".fryedScrollDragger").position();
			var elOffset 	= fryedScroll.offset();
			var maxY 		= height-draggerHeight;
			
			//set new pos
			var top 	= (e.pageY-elOffset.top)-draggerHeight/2;
			
			//lock to boundries
			if(top > maxY){
				top = maxY;
			}else if(top < 0){
				top = 0;
			}
			
			//move dragger
			fryedScroll.find(".fryedScrollDragger").css({
				"top" : top
			});

			//work out scrollDiv pos
			var scrollTo = top/fract;
			
			//move scroll content
			fryedScroll.find(".fryedScrollDiv").css({
				"top" : -scrollTo
			});
			
		}
		
		//-----stop scroll function-----//
		function stopScroll(){
			
			//rebind text select
			scrollDiv
				.removeAttr("unselectable")
				.css({
					"-moz-user-select"		: 	"text",
					"-webkit-user-select"	: 	"text",
					"user-select"			: 	"text"
				})
				.each(function(){
					$(this).bind("onselectstart");
				})
			;
			
		}
		
		//-----scroll wheel function-----//
		function scrollWheel(scroller,raw){

			//get dragger
			var jdrag = $(scroller).find(".fryedScrollDragger");
			
			//get data id
			data.dragId = jdrag.attr("data-dragId");
			
			//simulate mouse pos 
			var e = new Object();
			
			//work out up or down
			if(raw < 0){
				e.pageY = jdrag.position().top+$(scroller).offset().top;
			}else{
				e.pageY = jdrag.position().top+$(scroller).offset().top+jdrag.height();
			}
		
			//scroll
			scroll(e); 
			
		}
		
	});
	
}