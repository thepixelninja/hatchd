//perform when page is ready
$(document).ready(function(){
	
	$(".fryedScroll").fryedScroll({
		draggerColor : "#21a7e5",
		bgColor		 : "#383838"
	});
	
});
