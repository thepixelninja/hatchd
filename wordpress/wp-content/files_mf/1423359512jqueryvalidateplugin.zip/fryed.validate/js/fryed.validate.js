/*
 * jquery validate plugin
 * by ed fryer
 * www.fryed.co.uk
 */
jQuery.fn.fryedValidate = function(options){

	var defaults = {
		default_error_text	:	"This is a required field",
		email_error_text	:	"Please enter a valid email",
		number_error_text	:	"Please enter a valid number",
		zipcode_error_text	:	"Please enter a valid zipcode",
		url_error_text		:	"Please enter a valid url",
		callback			:	false,
		overwriteDefault	: 	false
	};
	
	var options = $.extend(defaults,options);
	
	return this.each(function(){
		
		//----------SETUP----------//
	
		//define vars
		var element = $(this);
		var fields	= element.find("input,textarea,select");
		
		//check html5 validation suppport
		var support = support();
	
		//set errors
		options.error = true;
		
		//add required message
		element.append("<p class='validateMsg'><sup>*</sup> = required field</p>");
		
		//setup fields
		element.find("[required='required']").each(function(i){
			var field = $(this);
			var label = field.next("label");
			field.data("label",label);
			if(!support["validation"]){
				if(!field.is(":checkbox") && !field.is(":radio")){
					var placeholder = field.attr("placeholder");
					field.val(placeholder);
				}
			}
			field.after("<sup>*</sup>"); 
		});
		
		//----------EVENTS----------//
		
		//handle focus and click on fields	
		fields.bind("click focus",function(){
			var field = $(this);
			handleEvent(field);
		});
		
		//handle blur on fields	 
		fields.blur(function(){
			var field = $(this);
			blur(field);
		});
		
		//check for errors on form submit
		element.submit(function(e){
			validateForm();
			if(options.error)
				e.preventDefault();
			if(options.callback && !options.error){
				e.preventDefault();
				options.callback();
			}				
		});
		
		//catch html5 validation
		if(options.overwriteDefault && support["validation"]){
			overwriteDefault();
		}
				
		//----------FUNCTIONS----------//
		
		//clear default values
		function clearDefault(field){
			if(field.is(":radio") || field.is(":checkbox") || support["validation"]){
				return false;
			}
			var placeholder = field.attr("placeholder");
			if(placeholder){
				var val = field.val();
				if(placeholder == val)
					field.val("");
			}
		}
		
		//handle blur on fields
		function blur(field){
			if(field.is(":radio") || field.is(":checkbox") || support["validation"]){
				return false;
			}
			var placeholder = field.attr("placeholder");
			if(placeholder){
				var val = field.val();
				if(val == ""){
					field.val(placeholder);
				}
			}
		}
		
		//handle click and focus on fields
		function handleEvent(field){
			//handle inputs
			if(field.is("input")){
				clearDefault(field);
				if(field.hasClass("error"))
					removeError(field);
				//handle radios
				if(field.is("input:radio")){
					var name = field.attr("name");
					var radioGroup = element.find("input:radio[name='"+name+"']");
					removeError(radioGroup);
				}
			}
			//handle selects
			if(field.is("select")){
				removeError(field);
			}
			//handle textareas
			if(field.is("textarea")){
				clearDefault(field);
				removeError(field);
			}
			//remove error on focus
			if(field.is(".error")){
				removeError(field);
			}	
		}
		
		//validate required fields
		function validateForm(){
			element.find("[required='required']").each(function(){
				var field = $(this);
				//handle inputs
				if(field.is("input"))
					validateInput(field);
				//handle selects
				if(field.is("select"))
					validateSelect(field);
				//handle texareas
				if(field.is("textarea"))
					validateTextarea(field);
				//check for errors
				var errors = element.find(".error").length;
				if(errors == 0)
					options.error = false;
				else
					options.error = true;
			});
			if(options.error)
				animateToError();
		}
		
		//validate inputs
		function validateInput(field){
			var type = field.attr("type");
			switch(type){
				//handle text input
				case "text":
					checkEmpty(field);
					//zipcode
					if(field.is(".zipCode"))
						checkZipcode(field);
				break;
				//handle passwords
				case "password":
					//-----to do-----//
				break;
				//handle checkboxes
				case "checkbox":
					checkChecked(field);
				break;
				//handle radios
				case "radio":
					checkRadio(field);
				break;
				//handle numbers
				case "number":
					checkEmpty(field);
					checkNumber(field);
				break;
				case "email":
					checkEmpty(field);
					checkEmail(field);
				break;
				case "url":
					checkEmpty(field);
					checkUrl(field);
				break;
			}
		}
		
		//validate selects
		function validateSelect(field){
			var val = field.val();
			if(val == ""){
				addError(field);
				field.find("option:first").text(options.default_error_text);
			}	
		}
		
		//validate textareas
		function validateTextarea(field){
			checkEmpty(field);
		}
				
		//check if field is empty
		function checkEmpty(field){
			var val = field.val();
			var placeholder = field.attr("placeholder");
			if(val == "" || val == placeholder){
				addError(field);
				field.val(options.default_error_text);
			}	
		}
		
		//check if radio is checked
		function checkRadio(field){
			var name = field.attr("name");
			var radioGroup = element.find("input:radio[name='"+name+"']");
			radioGroup.each(function(i){
				var checked = $(this).attr("checked");
				if(checked){
					removeError(radioGroup);
					return false;
				}else
					addError($(this));	
			});
		}
		
		//check if field is checked
		function checkChecked(field){
			var checked = field.attr("checked");
			if(!checked){
				addError(field);
			}	
		}
		
		//check if field contains number
		function checkNumber(field){
			var val = field.val();
			val = val.replace(/ /g,"");
			if(isNaN(val)){
				addError(field);
				field.val(options.number_error_text);	
			}	
		}
		
		//check if field is email
		function checkEmail(field){
			var val = field.val();
			function isValidEmail(email){					
				var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
				return pattern.test(email);
			}
			if(!isValidEmail(val)){
				addError(field);
				field.val(options.email_error_text);
			}		
		}
		
		//check if field is valid url
		function checkUrl(field){
			var val = field.val();
			function isValidUrl(url){
				var pattern = new RegExp(/(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/);
				return pattern.test(url);
			}
			if(!isValidUrl(val)){
				addError(field);
				field.val(options.url_error_text);
			}
		}
		
		//check if field is valid zipcode
		function checkZipcode(field){
			var val = field.val();
			val = val.replace(/ /g,"").replace("-","");
			field.val(val);
			if(val.length < 5 || val.length > 9){
				addError(field);
				field.val(options.zipcode_error_text);
			}	
		}
				
		//add error to field
		function addError(field){
			var hasError = field.hasClass("error");
			if(!hasError){
				field.addClass("error");
				animateArrow(field);
			}
		}
		
		//remove error from field
		function removeError(field){
			if(!field.is("input:checkbox,input:radio,select"))
				field.val("");
			field.removeClass("error");
			field.next(".errorArrow").fadeOut("fast",function(){
				$(this).remove();
			});
		}
		
		//animate arrow
		function animateArrow(field){
			var label		= field.data("label");
			var winWidth 	= $(window).width();
			var fieldWidth 	= field.width();
			var fieldHeight = field.height();
			var fieldOffset = field.offset();
			var arrowStart 	= winWidth+17;
			var arrowStop 	= fieldOffset.left+fieldWidth+17;
			var arrowTop 	= fieldOffset.top+fieldHeight/2-9;
			if(field.is("textarea")){
				arrowTop = fieldOffset.top;
			}
			if(label.length > 0){
				var lWidth 	= label.width();
				arrowStop  += lWidth;
			}
			var arrowCss	= {
				"top"		: arrowTop,
				"left"		: arrowStart,
				"position"	: "absolute",
				"z-index"	: "10"
			}
			field.after("<span class='errorArrow'></span>");
			var arrow = field.next(".errorArrow");
			arrow.css(arrowCss);
			arrow.animate({
				left		:	arrowStop
			},{	
				queue		:	false,
				duration	:	500,
				complete	:	function(){
					//finished animating
				}
			});	
		}
		
		//animate to first error
		function animateToError(){
			var to = element.find(".error:first").offset().top;
			$("html,body").not(":animated").animate({
				scrollTop : to-50
			},1000);
		}
		
		//overwrite default html5 validation
		function overwriteDefault(){
			document.addEventListener("invalid",function(e){
				e.preventDefault();
				var field = $(e.target);
				var errorTxt = $.prop(e.target,"validationMessage");
				if(!field.is("select,input:radio,input:checkbox"))
					field.val(errorTxt);
				else if(field.is("select"))
					field.find("option:first").text(errorTxt);
				addError(field);
				animateToError();
			},true);		
		}
		
		//check html5 support
		function support(){
			var support = new Array();
			support["validation"] = false;
			var inputs 	= ["number","email","url"];
			for(i = 0; i<inputs.length; i++){
				var input = document.createElement("input");
				input.setAttribute("type",inputs[i]);
				if(input.type == inputs[i]){
					support[inputs[i]] = true;
					support["validation"] = true;
				}else
					support[inputs[i]] = false;
			}
			return support;
		}
		
	});
	
}	

