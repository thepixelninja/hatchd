$(document).ready(function(){
	
	//init plugin
	$(".validate").fryedValidate({
		//callback			:	callback,
		overwriteDefault 	: 	true
	});
	
	function callback(){
		alert("ajax me");
	}
	
});