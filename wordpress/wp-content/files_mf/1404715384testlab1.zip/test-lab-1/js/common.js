/*----------ON DOCUMENT READY----------*/

$(document).ready(function(){
	
	console.log("Go go gadget test lab");
	
});

