<!DOCTYPE html>
<html lang="en">
	
<head>
	
<meta charset="utf-8" />

<title>Test Lab</title>

<link rel="stylesheet" href="css/screen.css" type="text/css" />

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>

</head>

<body>
	
	<h1>Im a test lab</h1>
	<img src="images/fryed-logo.png"/>
	
</body>

</html>