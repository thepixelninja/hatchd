//perform when page is ready
$(document).ready(function(){
	
	$(".googleMap").fryedGooglemap({
		width		: 500,
		height		: 400,
		postcode 	: "b168uu"
	});
	
});