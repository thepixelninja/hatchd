//perform when page is ready
$(document).ready(function(){
	
	//run popup plugin
	$("a.popup").fryedPopup();
	
	//run confirm plugin
	$("a.confirm").fryedConfirm({
		callback : onAnswer
	});
	
	//run custom on answer
	function onAnswer(answer){
		if(answer)
			alert("confirm");
		else
			alert("deny");	
	}
	
});