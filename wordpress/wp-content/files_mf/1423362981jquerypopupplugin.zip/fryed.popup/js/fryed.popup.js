/*-------------------------------//
 * 
 * FRYED.POPUP.JS
 * JQUERY POPUP AND CONFIRM PLUGINS
 * WRITTEN BY ED FRYER
 * WWW.FRYED.CO.UK
 * 
 -------------------------------*/

function setGlobalVars(){
	
	window.winHeight	= $(window).height();
	window.winWidth		= $(window).width();
	window.docHeight	= $(document).height();
	window.docWidth		= $(document).width();
	
} 

//popup plugin
$.fn.fryedPopup = function(options){

	var defaults = {
		popupSpeed 		: "fast",
		overlaySpeed	: "fast",
		width			: "500px"
	};
	
	var options = $.extend(defaults, options);
	
	return this.each(function(){
		
		//setup all the main global vars
		setGlobalVars();
		
		//re-calculate dimensions on window resize
		$(window).resize(function(){
			setGlobalVars();
		});
	
		$(this).each(function(i){
			i++;
			var href = $(this).attr("href");
			$(href).hide("");
		});
	
		$(this).click(function(e){
			e.preventDefault();
			var element = $(this);
			var href = element.attr("href");
			var title = element.attr("title");
			var hasAnchor = href.lastIndexOf("#");
			var hrefArray = href.split("#");
			var id = "#"+hrefArray[1];
			if($(id).length > 0){
				var content = $(id).html();
				openOverlay(options.overlaySpeed,function(){
					openPopup(options.popupSpeed,title,content,options.width);
				});	
			}else{
				if(hrefArray[0] == ""){
					hrefArray[0] = window.location.href;
				}
				$.get(hrefArray[0],function(content){
					if(hasAnchor != -1){
						content = $(content).filter(id).html();
					}	
					openOverlay(options.overlaySpeed,function(){
						openPopup(options.popupSpeed,title,content,options.width);
					});	
				});
			}
			
		});
		
		$("#fryedPopup .close, .fryedOverlay").live("click",function(){
			closePopup(options.popupSpeed,function(){
				closeOverlay(options.overlaySpeed);
			});
		});
		
	});
	
}

//confirm plugin
$.fn.fryedConfirm = function(options){

	var defaults = {
		question 		: "Are you sure?",
		buttonPos		: "Yes",
		buttonNeg		: "No",
		callback		: function callback(){},
		popupSpeed 		: "fast",
		overlaySpeed	: "fast",
		width			: "200px"
	};
	
	var options = $.extend(defaults, options);
	
	return this.each(function(){
		
		//setup all the main global vars
		setGlobalVars();
		
		//re-calculate dimensions on window resize
		$(window).resize(function(){
			setGlobalVars();
		});
	
		$(this).click(function(e){
			e.preventDefault();
			var element = $(this);
			var href = element.attr("href");
			var title = element.attr("title");
			var content = "<p>"+options.question+"</p>\
			<br class='clearBoth'/>\
			<input type='button' class='neg' value='"+options.buttonNeg+"' name='false'/>\
			<input type='button' class='pos' value='"+options.buttonPos+"' name='true'/>\
			<br class='clearBoth'/>";
			openOverlay(options.overlaySpeed,function(){
				openPopup(options.popupSpeed,title,content,options.width);
				$(".popupContent").addClass("confirmDialogue");
				$("#fryedPopup .close").remove();
			});		
		});
		
		$("#fryedPopup input:button").live("click",function(){
			if($(this).attr("name") == "true")
				answer = true;
			else
				answer = false;	
			closePopup(options.popupSpeed,function(){
				closeOverlay(options.overlaySpeed,function(){
					options.callback(answer);
				});
			});
		});
		
	});
	
}		

//function to open overlay
function openOverlay(speed,callback){
	
	setGlobalVars();
	
	$("body").append("<div class='fryedOverlay'></div>");
	$(".fryedOverlay").css({
		"width"		:	window.docWidth,
		"height"	:	window.docHeight
	}).animate({
		opacity		:	0.8
	},1,function(){
		$(".fryedOverlay").fadeIn(speed,function(){
			if(callback)
				callback();
		});
	});
	
}

//function to close overlay
function closeOverlay(speed,callback){
	
	$(".fryedOverlay").fadeOut(speed,function(){
		$(".fryedOverlay").remove();
		if(callback)
			callback();
	});
	
}

//function to open a popup
function openPopup(speed,title,content,width,callback){
	
	setGlobalVars();
	
	$("body").append("<div id='fryedPopup'>\
		<div class='popupHeader'>\
			<span class='close'></span>\
			<h2>"+title+"</h2>\
		</div>\
		<div class='popupContent'>"+content+"</div>\
	</div>");
	
	if(width)
		$("#fryedPopup").css("width",width);
	
	var left 	= window.winWidth/2 - $("#fryedPopup").width()/2;
	var top 	= (window.winHeight/2 - $("#fryedPopup").height()/2) + $(window).scrollTop();
	
	$("#fryedPopup").css({
		"top"	:	top,
		"left"	:	left
	}).fadeIn(speed,function(){
		if(callback)
			callback();
	});
	
}

//function to close popup
function closePopup(speed,callback){
	
	$("#fryedPopup").fadeOut(speed,function(){
		$("#fryedPopup").remove();
		if(callback)
			callback();
	});
	
}
